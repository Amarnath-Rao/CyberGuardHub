import {
    BrowserRouter as Router,
    Link,
} from "react-router-dom";
import { useEffect, useState } from 'react';
import { useLocation } from 'react-router';

function footer(){
    <div>
        <footer>
            
        </footer>
    </div>
}